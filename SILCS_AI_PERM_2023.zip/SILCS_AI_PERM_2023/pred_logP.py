#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Copyright (c) 2023, University of Maryland Baltimore All Rights Reserved

Poonam Pandey and Alexander D. MacKerell, Jr

Script to predict the experimental logP values using four ML algorithms:
    [1] Random Forest Regressor
    [2] GradientBoosting Regressor
    [3] Xgboost Regressor
    [4] Lightgbm Regressor
"""
import numpy as np
import pandas as pd
import joblib
from sklearn.metrics import r2_score, mean_squared_error
if __name__ == "__main__": 
    inp_dir='lgfe_permm_manuscript_2023' 
    training_dataset=inp_dir+"/train_permm.csv" 
    test_dataset=inp_dir+"/test_permm.csv" 
    train_dataset, test_dataset = pd.read_csv(training_dataset,index_col=0), pd.read_csv(test_dataset,index_col=0) 
    train_lgfe, train_exp = train_dataset.drop('Exp',axis=1).values, train_dataset['Exp'].values 
    test_lgfe, test_exp = test_dataset.drop('Exp',axis=1).values, test_dataset['Exp'].values

    df=pd.DataFrame()
    df1=pd.DataFrame()
    
    loaded_model = joblib.load("rf.joblib")
    print('\n-- Selected Hyperparameters for Random Forest Regressor Algorithm --\n')
    for i, key in enumerate(loaded_model.get_params().keys()):
        print('['+str(i+1)+'] ', key,' : ', loaded_model.get_params()[key])
    
    df['Target_train']=train_exp
    df['Pred_RF']=loaded_model.predict(train_lgfe)
    df1['Target_test']=test_exp
    df1['Pred_RF']=loaded_model.predict(test_lgfe)
    
    print('\n-- RMSE and R2 values for training and test dataset from Random Forest Regressor Algorithm --\n')
    rmse=np.sqrt(mean_squared_error(train_exp, loaded_model.predict(train_lgfe)))
    r_square=r2_score(train_exp, loaded_model.predict(train_lgfe))
    print('Training RMSE: ', round(rmse,3))
    print('Training R2: ', round(r_square,3))
    
    
    loaded_model = joblib.load("gb.joblib")
    print('\n-- Selected Hyperparameters for GradientBoosting Regressor Algorithm --\n')
    for i, key in enumerate(loaded_model.get_params().keys()):
        print('['+str(i+1)+'] ', key,' : ', loaded_model.get_params()[key])
        
    df['Pred_GB']=loaded_model.predict(train_lgfe)
    df1['Pred_GB']=loaded_model.predict(test_lgfe)
    
    print('\n-- RMSE and R2 values for training and test dataset from GradientBoosting Regressor Algorithm --\n')
    rmse=np.sqrt(mean_squared_error(train_exp, loaded_model.predict(train_lgfe)))
    r_square=r2_score(train_exp, loaded_model.predict(train_lgfe))
    print('Training RMSE: ', round(rmse,3))
    print('Training R2: ', round(r_square,3))
    
    loaded_model = joblib.load("lgbm.joblib")
    print('\n-- Selected Hyperparameters for Lightgbm Regressor Algorithm --\n')
    for i, key in enumerate(loaded_model.get_params().keys()):
        print('['+str(i+1)+'] ', key,' : ', loaded_model.get_params()[key])
        
    df['Pred_LGBM']=loaded_model.predict(train_lgfe)
    df1['Pred_LGBM']=loaded_model.predict(test_lgfe)
    
    print('\n-- RMSE and R2 values for training and test dataset from Lightgbm Regressor Algorithm --\n')
    rmse=np.sqrt(mean_squared_error(train_exp, loaded_model.predict(train_lgfe)))
    r_square=r2_score(train_exp, loaded_model.predict(train_lgfe))
    print('Training RMSE: ', round(rmse,3))
    print('Training R2: ', round(r_square,3))

    loaded_model = joblib.load("xgb.joblib")
    print('\n-- Selected Hyperparameters for Xgboost Regressor Algorithm --\n')
    for i, key in enumerate(loaded_model.get_params().keys()):
        print('['+str(i+1)+'] ', key,' : ', loaded_model.get_params()[key])
        
    df['Pred_XGB']=loaded_model.predict(train_lgfe)
    df1['Pred_XGB']=loaded_model.predict(test_lgfe)
    
    print('\n-- RMSE and R2 values for training and test dataset from Xgboost Regressor Algorithm --\n')
    rmse=np.sqrt(mean_squared_error(train_exp, loaded_model.predict(train_lgfe)))
    r_square=r2_score(train_exp, loaded_model.predict(train_lgfe))
    print('Training RMSE: ', round(rmse,3))
    print('Training R2: ', round(r_square,3))
    
    df.to_csv('Training_pred.csv')
    df1.to_csv('Test_pred.csv')
