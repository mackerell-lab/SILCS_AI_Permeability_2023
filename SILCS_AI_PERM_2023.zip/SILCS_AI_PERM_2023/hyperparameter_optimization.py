#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hyperparameter optimization using GridSearchCV
"""

import pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import GridSearchCV
import lightgbm as lgb
import xgboost as xgb
import warnings
warnings.filterwarnings('ignore')

class Regressor_hyperParamOpt(object):
  """
    HyperParameter Optimization using GridSearchCV
  """
  def __init__(self, training_dataset,test_dataset):
    # Importing the dataset
    self.selected = None
    self.train_dataset, self.test_dataset = pd.read_csv(training_dataset,index_col=0), pd.read_csv(test_dataset,index_col=0)
    self.train_lgfe, self.train_exp = self.train_dataset.drop('Exp',axis=1).values, self.train_dataset['Exp'].values
    self.test_lgfe, self.test_exp = self.test_dataset.drop('Exp',axis=1).values, self.test_dataset['Exp'].values
    
    self.regressor_rf = RandomForestRegressor()
    self.regressor_lgb = lgb.LGBMRegressor()
    self.regressor_xgb = xgb.XGBRegressor()
    self.regressor_gb = GradientBoostingRegressor() 

  
  def grid_search_RF(self):
        """
        Hyperparameter optimization with GridSearch search for Random Forest Regressor
        :return: dict
            Returns best parameters
        """
        # Number of trees in random forest
        n_estimators=[20, 40, 60, 80, 100]
        # Number of features to consider at every split
        max_features = [2, 5, 7, 10, 12, 15]
        # Maximum number of levels in tree
        max_depth = [5, 10, 20, 30, 40, 50, None]
        # Set warm_start 
        warm_start = ['True','False']
        bootstrap = ['True','False']


        grid_search_cv = {'n_estimators': n_estimators,
                       'max_features': max_features,
                       'max_depth': max_depth,
                       'warm_start': warm_start,
                       'bootstrap': bootstrap
                       }

        regressor_grid_search = GridSearchCV(estimator= self.regressor_rf,
                                param_grid= grid_search_cv,
                                scoring='neg_mean_squared_error',
                                cv=10, 
                                n_jobs=-1)
        regressor_grid_search.fit(self.train_lgfe, self.train_exp)

        return regressor_grid_search.best_params_

  def grid_search_LGBM(self):
        """
        Hyperparameter optimization with GridSearch search for Lightgbm
Regressor
        :return: dict
            Returns best parameters
        """
        # Number of boosted trees to fit.
        n_estimators=[20, 40, 60, 80, 100]
        # Boosting learning rate
        learning_rate = [0.06, 0.08, 0.1, 0.2]
        # Maximum tree depth for base learners
        max_depth = [5, 10, 12, 15, 50, None]
        # Matric
        metric = ['l2','l1']
        # boosting type
        boosting = ['gbdt','dart']

        grid_search_cv = {'n_estimators': n_estimators,
                       'learning_rate': learning_rate,
                       'max_depth': max_depth,
                       'metric': metric,
                       'boosting': boosting}

        regressor_grid_search = GridSearchCV(estimator= self.regressor_lgb,
                                param_grid= grid_search_cv,
                                scoring='neg_mean_squared_error',
                                cv=10, 
                                n_jobs=-1)
        regressor_grid_search.fit(self.train_lgfe, self.train_exp)

        return regressor_grid_search.best_params_

  def grid_search_XGB(self):
        """
        Hyperparameter optimization with GridSearch search for Xgboost
Regressor
        :return: dict
            Returns best parameters
        """

        # Number of gradient boosted trees
        n_estimators=[20, 30, 40, 50, 60]
        # Boosting learning rate
        learning_rate = [0.04, 0.06, 0.08, 0.1]
        # Maximum tree depth for base learners
        max_depth = [2, 3, 4, 6, 8, 10, None]
        # Matric
        metric = ['l2','l1']
        # booster type
        booster = ['gbtree','dart']



        grid_search_cv = {'n_estimators': n_estimators,
                       'learning_rate': learning_rate,
                       'max_depth': max_depth,
                       'metric': metric,
                       'booster': booster}

        regressor_grid_search = GridSearchCV(estimator= self.regressor_xgb,
                                param_grid= grid_search_cv,
                                scoring='neg_mean_squared_error',
                                cv=10, 
                                n_jobs=-1)
        regressor_grid_search.fit(self.train_lgfe, self.train_exp)

        return regressor_grid_search.best_params_

  def grid_search_GB(self):
        """
        Hyperparameter optimization with GridSearch search for GradientBoosting Regressor
        :return: dict
            Returns best parameters
        """

        # Number of trees in random forest
        n_estimators=[20, 40, 60, 80, 100]
        # Number of features to consider at every split
        max_features = ['auto', 'sqrt'] 
        # Maximum number of levels in tree
        max_depth = [2, 4, 6, 8, 10, 12, 15, None]
        # Minimum number of samples required to split a node
        min_samples_split = [3, 5, 10, 12]
        # Minimum number of samples required at each leaf node
        min_samples_leaf = [2, 4, 6]
        # Set warm_start 
        warm_start = ['True','False']



        grid_search_cv = {'n_estimators': n_estimators,
                       'max_features': max_features,
                       'max_depth': max_depth,
                       'min_samples_split': min_samples_split,
                       'min_samples_leaf': min_samples_leaf,
                       'warm_start': warm_start
                       }

        regressor_grid_search = GridSearchCV(estimator= self.regressor_gb,
                                param_grid= grid_search_cv,
                                scoring='neg_mean_squared_error',
                                cv=10, 
                                n_jobs=-1)
        regressor_grid_search.fit(self.train_lgfe, self.train_exp)

        return regressor_grid_search.best_params_
    
def init_main():
    inp_dir='lgfe_perm_input_data_2023'
    opt_param_XGB = Regressor_hyperParamOpt(training_dataset=inp_dir+"/train_perm_model_data.csv",test_dataset=inp_dir+"/test_perm_model_data.csv").grid_search_XGB()
    opt_param_LGBM = Regressor_hyperParamOpt(training_dataset=inp_dir+"/train_perm_model_data.csv",test_dataset=inp_dir+"/test_perm_model_data.csv").grid_search_LGBM()
    opt_param_GB = Regressor_hyperParamOpt(training_dataset=inp_dir+"/train_perm_model_data.csv",test_dataset=inp_dir+"/test_perm_model_data.csv").grid_search_GB()
    opt_param_RF = Regressor_hyperParamOpt(training_dataset=inp_dir+"/train_perm_model_data.csv",test_dataset=inp_dir+"/test_perm_model_data.csv").grid_search_RF()
    
    
    
    